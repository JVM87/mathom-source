# -*- coding: utf-8 -*-
import os
import shutil
import subprocess
import tempfile
import time
import urllib.parse as urlparse
import urllib.request
import xbmcgui # type: ignore
import xbmc # type: ignore
import xbmcaddon # type: ignore
import xbmcvfs # type: ignore

def join_vfs_path(base_path: str, filename: str) -> str:
    separator = '' if base_path.endswith(('/', '\\')) else '/'
    return f"{base_path}{separator}{filename}"

def split_kodi_url(url: str):
    if '|' not in url:
        return url, {}

    media_url, header_query = url.split('|', 1)
    headers = {}
    for key, value in urlparse.parse_qsl(header_query, keep_blank_values=True):
        if key:
            headers[key] = value
    return media_url, headers

def is_manifest_url(url: str) -> bool:
    path = urlparse.urlparse(url).path.lower()
    return path.endswith(('.m3u8', '.mpd'))

def headers_to_ffmpeg_args(headers: dict) -> list:
    if not headers:
        return []

    header_lines = ''.join(f'{key}: {value}\r\n' for key, value in headers.items())
    return ['-headers', header_lines]

def with_default_headers(headers: dict) -> dict:
    request_headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/Mathom'
    }
    request_headers.update(headers)
    return request_headers

def get_addon_bool(addon, setting_id: str, default: bool = False) -> bool:
    try:
        value = addon.getSetting(setting_id)
        if value == '':
            return default
        return value.lower() in ('true', '1', 'yes', 'on')
    except Exception:
        xbmc.log(f"Mathom: Ajuste booleano inválido '{setting_id}', usando {default}", xbmc.LOGWARNING)
        return default

class DownloadCanceled(Exception):
    pass

class DownloadPaused(Exception):
    pass

def format_eta(seconds: float) -> str:
    if seconds <= 0:
        return "--:--"
    minutes, secs = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours:d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"

class SimpleDownloader:
    """Motor de descarga optimizado para Kodi."""
    
    def __init__(self, download_path: str, foreground: bool = True, progress_callback=None, control_callback=None):
        self.download_path: str = download_path
        self.addon: xbmcaddon.Addon = xbmcaddon.Addon()
        self.icon: str = self.addon.getAddonInfo('icon')
        self.foreground = foreground
        self.progress_callback = progress_callback
        self.control_callback = control_callback
        
        if not xbmcvfs.exists(self.download_path):
            try:
                xbmcvfs.mkdirs(self.download_path)
            except Exception as e:
                xbmc.log(f"Mathom: Error fatal creando directorio: {str(e)}", xbmc.LOGERROR)

    def get_ffmpeg_path(self) -> str:
        configured_path = self.addon.getSetting('ffmpeg_path')
        if configured_path and xbmcvfs.exists(configured_path):
            return xbmcvfs.translatePath(configured_path)

        return shutil.which('ffmpeg') or ''

    def get_local_path(self, path: str) -> str:
        if path.startswith('special://'):
            return xbmcvfs.translatePath(path)
        return path

    def get_partial_size(self, path: str) -> int:
        try:
            if xbmcvfs.exists(path):
                return int(xbmcvfs.Stat(path).st_size())
        except Exception:
            return 0
        return 0

    def download_http(self, url: str, filename: str, resume: bool = False) -> bool:
        """Inicia una descarga HTTP asíncrona sin bloquear la UI."""
        dest_path: str = join_vfs_path(self.download_path, filename)
        
        if xbmcvfs.exists(dest_path) and not resume:
            choice = xbmcgui.Dialog().yesno("Mathom", f"El archivo '{filename}' ya existe.\n¿Deseas sobrescribirlo?")
            if not choice:
                return False

        media_url, headers = split_kodi_url(url)
        headers = with_default_headers(headers)
        if is_manifest_url(media_url):
            return self._download_with_ffmpeg(media_url, headers, filename, dest_path)

        return self._download_worker(media_url, headers, filename, dest_path, resume)

    def _download_worker(self, url: str, headers: dict, filename: str, dest_path: str, resume: bool = False) -> bool:
        """Descarga directa con progreso visible y cancelación."""
        dp = xbmcgui.DialogProgress() if self.foreground else xbmcgui.DialogProgressBG()
        dp.create("Mathom", f"Descargando: {filename}")
        
        try:
            xbmc.log(f"Mathom: Iniciando descarga HTTP: {url}", xbmc.LOGINFO)
            resume_from = self.get_partial_size(dest_path) if resume else 0
            request_headers = dict(headers)
            if resume_from > 0:
                request_headers['Range'] = f'bytes={resume_from}-'
            req = urllib.request.Request(url, headers=request_headers)
            
            with urllib.request.urlopen(req, timeout=30) as response:
                content_length = int(response.info().get('Content-Length', -1))
                status_code = getattr(response, 'status', response.getcode())
                if resume_from > 0 and status_code == 200:
                    xbmc.log("Mathom: El servidor no soportó Range; reiniciando descarga.", xbmc.LOGWARNING)
                    resume_from = 0
                total_size = content_length + resume_from if content_length > 0 else -1
                downloaded = resume_from
                session_downloaded = 0
                chunk_size = 256 * 1024
                started_at = time.time()
                
                local_dest_path = self.get_local_path(dest_path)
                is_vfs_dest = '://' in dest_path
                if not is_vfs_dest:
                    output_dir = os.path.dirname(local_dest_path)
                    if output_dir and not os.path.exists(output_dir):
                        os.makedirs(output_dir, exist_ok=True)
                    out_file = open(local_dest_path, 'ab' if resume_from > 0 else 'wb')
                else:
                    out_file = xbmcvfs.File(dest_path, 'ab' if resume_from > 0 else 'wb')
                try:
                    while True:
                        if self.foreground and dp.iscanceled():
                            raise DownloadCanceled("Descarga cancelada por el usuario.")
                        if self.control_callback:
                            control = self.control_callback()
                            if control == 'pause':
                                raise DownloadPaused("Descarga pausada por el usuario.")
                            if control == 'cancel':
                                raise DownloadCanceled("Descarga cancelada por el usuario.")

                        chunk = response.read(chunk_size)
                        if not chunk: break
                        out_file.write(chunk)
                        downloaded += len(chunk)
                        session_downloaded += len(chunk)
                        
                        elapsed = max(time.time() - started_at, 0.1)
                        speed = session_downloaded / elapsed
                        speed_mib = speed / 1048576
                        if total_size > 0:
                            percent = min(int(downloaded * 100 / total_size), 100)
                            remaining = max(total_size - downloaded, 0)
                            eta = format_eta(remaining / speed) if speed > 0 else "--:--"
                            if self.progress_callback:
                                self.progress_callback(percent, downloaded, total_size, speed_mib, eta)
                            message = (
                                f"{filename}\n"
                                f"{downloaded / 1048576:.1f} MB / {total_size / 1048576:.1f} MB"
                                f"  -  {speed_mib:.1f} MB/s  -  ETA {eta}"
                            )
                            dp.update(percent, message)
                        else:
                            if self.progress_callback:
                                self.progress_callback(0, downloaded, 0, speed_mib, "")
                            dp.update(0, f"{filename}\n{downloaded / 1048576:.1f} MB  -  {speed_mib:.1f} MB/s")
                finally:
                    out_file.close()

            dp.close()
            
            # Notificación de éxito (si está habilitada en ajustes)
            if get_addon_bool(self.addon, 'show_notifications', True):
                xbmcgui.Dialog().notification("Mathom", f"¡Completado!: {filename}", self.icon, 5000)
            return True

        except DownloadCanceled as e:
            if dp: dp.close()
            xbmc.log(f"Mathom: {str(e)}", xbmc.LOGINFO)
            if xbmcvfs.exists(dest_path):
                try: xbmcvfs.delete(dest_path)
                except: pass
            xbmcgui.Dialog().notification("Mathom", "Descarga cancelada", self.icon, 3000)
            return False

        except DownloadPaused as e:
            if dp: dp.close()
            xbmc.log(f"Mathom: {str(e)}", xbmc.LOGINFO)
            xbmcgui.Dialog().notification("Mathom", "Descarga pausada", self.icon, 3000)
            return False

        except Exception as e:
            if dp: dp.close()
            xbmc.log(f"Mathom: Error en descarga: {str(e)}", xbmc.LOGERROR)
            if xbmcvfs.exists(dest_path):
                try: xbmcvfs.delete(dest_path)
                except: pass
            xbmcgui.Dialog().ok("Mathom - Error", f"Se interrumpió la descarga de:\n{filename}\n\nError: {str(e)}")
            return False

    def _download_with_ffmpeg(self, url: str, headers: dict, filename: str, dest_path: str) -> bool:
        ffmpeg_path = self.get_ffmpeg_path()
        if not ffmpeg_path:
            xbmcgui.Dialog().ok(
                "Mathom",
                "Este enlace es HLS/DASH y requiere ffmpeg.\nConfigura la ruta de ffmpeg en los ajustes del addon."
            )
            return False

        local_dest_path = self.get_local_path(dest_path)
        is_vfs_dest = '://' in dest_path
        output_dir = os.path.dirname(local_dest_path)
        if not is_vfs_dest and output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)

        dp = xbmcgui.DialogProgress() if self.foreground else xbmcgui.DialogProgressBG()
        dp.create("Mathom", f"Procesando stream: {filename}")

        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.mp4')
        temp_path = temp_file.name
        temp_file.close()
        error_file = tempfile.NamedTemporaryFile(delete=False, suffix='.log')
        error_path = error_file.name
        error_file.close()

        try:
            if is_vfs_dest and xbmcvfs.exists(dest_path):
                xbmcvfs.delete(dest_path)
            elif not is_vfs_dest and os.path.exists(local_dest_path):
                os.remove(local_dest_path)

            command = [
                ffmpeg_path,
                '-y',
                '-hide_banner',
                '-loglevel', 'error',
                *headers_to_ffmpeg_args(headers),
                '-i', url,
                '-c', 'copy',
                '-bsf:a', 'aac_adtstoasc',
                temp_path,
            ]

            with open(error_path, 'wb') as stderr_file:
                process = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=stderr_file)
                while process.poll() is None:
                    if self.foreground and dp.iscanceled():
                        process.terminate()
                        raise DownloadCanceled("Descarga cancelada por el usuario.")
                    xbmc.sleep(1000)
                    if self.progress_callback:
                        self.progress_callback(0, 0, 0, 0.0, "")
                    dp.update(0, f"{filename}\nDescargando y ensamblando stream...")

            if process.returncode != 0:
                with open(error_path, 'rb') as stderr_file:
                    error_text = stderr_file.read().decode('utf-8', errors='ignore').strip()
                if 'DRM' in error_text.upper() or 'CENC' in error_text.upper() or 'ENCRYPT' in error_text.upper():
                    message = "El stream parece estar protegido o cifrado y no se puede guardar offline."
                else:
                    message = error_text[-600:] if error_text else "ffmpeg no pudo procesar el stream."
                raise RuntimeError(message)

            if is_vfs_dest:
                with open(temp_path, 'rb') as source:
                    out_file = xbmcvfs.File(dest_path, 'wb')
                    try:
                        while True:
                            chunk = source.read(256 * 1024)
                            if not chunk:
                                break
                            out_file.write(chunk)
                    finally:
                        out_file.close()
            else:
                shutil.move(temp_path, local_dest_path)
                temp_path = ''

            dp.close()
            if get_addon_bool(self.addon, 'show_notifications', True):
                xbmcgui.Dialog().notification("Mathom", f"¡Completado!: {filename}", self.icon, 5000)
            return True

        except DownloadCanceled as e:
            if dp: dp.close()
            xbmc.log(f"Mathom: {str(e)}", xbmc.LOGINFO)
            if xbmcvfs.exists(dest_path):
                try: xbmcvfs.delete(dest_path)
                except: pass
            xbmcgui.Dialog().notification("Mathom", "Descarga cancelada", self.icon, 3000)
            return False
        except Exception as e:
            if dp: dp.close()
            xbmc.log(f"Mathom: Error procesando stream: {str(e)}", xbmc.LOGERROR)
            if xbmcvfs.exists(dest_path):
                try: xbmcvfs.delete(dest_path)
                except: pass
            xbmcgui.Dialog().ok("Mathom - Error", f"No se pudo guardar el stream:\n{filename}\n\n{str(e)}")
            return False
        finally:
            if temp_path and os.path.exists(temp_path):
                try: os.remove(temp_path)
                except: pass
            if error_path and os.path.exists(error_path):
                try: os.remove(error_path)
                except: pass

    def download_torrent(self, magnet_or_url: str) -> bool:
        xbmcgui.Dialog().ok("Mathom", "La descarga de Torrents P2P estará disponible próximamente.")
        return False
