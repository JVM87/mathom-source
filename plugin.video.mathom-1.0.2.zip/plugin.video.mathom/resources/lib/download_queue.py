# -*- coding: utf-8 -*-
import json
import os
import time
import uuid
from typing import Dict, List, Optional

import xbmc # type: ignore
import xbmcvfs # type: ignore


ADDON_DATA_PATH = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.mathom')
LEGACY_ADDON_DATA_PATH = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.torrentoffline')
QUEUE_PATH = os.path.join(ADDON_DATA_PATH, 'downloads.json')
LEGACY_QUEUE_PATH = os.path.join(LEGACY_ADDON_DATA_PATH, 'downloads.json')
LOCK_PATH = os.path.join(ADDON_DATA_PATH, 'downloads.lock')
LOCK_TIMEOUT = 5.0
RETRY_DELAY = 0.05


def ensure_data_path() -> None:
    if not os.path.exists(ADDON_DATA_PATH):
        os.makedirs(ADDON_DATA_PATH, exist_ok=True)
    migrate_legacy_queue()


def migrate_legacy_queue() -> None:
    if os.path.exists(QUEUE_PATH) or not os.path.exists(LEGACY_QUEUE_PATH):
        return

    try:
        with open(LEGACY_QUEUE_PATH, 'r', encoding='utf-8') as legacy_file:
            data = json.load(legacy_file)
        if not isinstance(data, list):
            return
        with open(QUEUE_PATH, 'w', encoding='utf-8') as queue_file:
            json.dump(data, queue_file, ensure_ascii=False, indent=2)
        xbmc.log("Mathom: cola migrada desde plugin.video.torrentoffline", xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log(f"Mathom: no se pudo migrar la cola antigua: {str(exc)}", xbmc.LOGWARNING)


def now() -> int:
    return int(time.time())


def acquire_lock() -> bool:
    ensure_data_path()
    deadline = time.time() + LOCK_TIMEOUT
    while time.time() < deadline:
        try:
            fd = os.open(LOCK_PATH, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, 'w', encoding='utf-8') as lock_file:
                lock_file.write(str(os.getpid()))
            return True
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(LOCK_PATH) > LOCK_TIMEOUT:
                    os.remove(LOCK_PATH)
                    continue
            except OSError:
                pass
            time.sleep(RETRY_DELAY)
        except OSError as exc:
            xbmc.log(f"Mathom: No se pudo crear bloqueo de cola: {str(exc)}", xbmc.LOGWARNING)
            time.sleep(RETRY_DELAY)
    return False


def release_lock() -> None:
    try:
        if os.path.exists(LOCK_PATH):
            os.remove(LOCK_PATH)
    except OSError as exc:
        xbmc.log(f"Mathom: No se pudo liberar bloqueo de cola: {str(exc)}", xbmc.LOGWARNING)


def load_queue() -> List[Dict]:
    ensure_data_path()
    if not os.path.exists(QUEUE_PATH):
        return []

    last_error = None
    for _ in range(20):
        try:
            with open(QUEUE_PATH, 'r', encoding='utf-8') as queue_file:
                data = json.load(queue_file)
            return data if isinstance(data, list) else []
        except (PermissionError, json.JSONDecodeError, OSError) as exc:
            last_error = exc
            time.sleep(RETRY_DELAY)
        except Exception as exc:
            last_error = exc
            break

    if last_error:
        xbmc.log(f"Mathom: Error leyendo cola: {str(last_error)}", xbmc.LOGWARNING)
    return []


def save_queue(queue: List[Dict]) -> None:
    ensure_data_path()
    if not acquire_lock():
        raise RuntimeError("No se pudo bloquear la cola de descargas.")

    temp_path = f"{QUEUE_PATH}.{os.getpid()}.tmp"
    try:
        with open(temp_path, 'w', encoding='utf-8') as queue_file:
            json.dump(queue, queue_file, ensure_ascii=False, indent=2)

        last_error = None
        for _ in range(40):
            try:
                os.replace(temp_path, QUEUE_PATH)
                return
            except PermissionError as exc:
                last_error = exc
                time.sleep(RETRY_DELAY)
            except OSError as exc:
                last_error = exc
                time.sleep(RETRY_DELAY)
        raise RuntimeError(f"No se pudo guardar la cola de descargas: {str(last_error)}")
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                pass
        release_lock()


def enqueue_download(url: str, filename: str, title: str) -> Dict:
    queue = load_queue()
    item = {
        'id': str(uuid.uuid4()),
        'url': url,
        'filename': filename,
        'title': title,
        'status': 'queued',
        'progress': 0,
        'downloaded': 0,
        'total': 0,
        'speed': 0.0,
        'eta': '',
        'error': '',
        'created_at': now(),
        'updated_at': now(),
    }
    queue.append(item)
    save_queue(queue)
    return item


def update_item(item_id: str, updates: Dict) -> Optional[Dict]:
    queue = load_queue()
    updated_item = None
    for item in queue:
        if item.get('id') == item_id:
            item.update(updates)
            item['updated_at'] = now()
            updated_item = item
            break
    save_queue(queue)
    return updated_item


def get_item(item_id: str) -> Optional[Dict]:
    for item in load_queue():
        if item.get('id') == item_id:
            return item
    return None


def set_status(item_id: str, status: str, error: str = '') -> Optional[Dict]:
    updates = {'status': status}
    if error:
        updates['error'] = error
    return update_item(item_id, updates)


def get_next_queued() -> Optional[Dict]:
    for item in load_queue():
        if item.get('status') in ('queued', 'resuming'):
            return item
    return None


def list_active() -> List[Dict]:
    return [item for item in load_queue() if item.get('status') in ('queued', 'resuming', 'downloading', 'pausing', 'paused', 'canceling')]


def mark_stale_running_as_queued() -> None:
    queue = load_queue()
    changed = False
    for item in queue:
        if item.get('status') in ('downloading', 'pausing', 'canceling'):
            item['status'] = 'queued'
            item['updated_at'] = now()
            changed = True
    if changed:
        save_queue(queue)
