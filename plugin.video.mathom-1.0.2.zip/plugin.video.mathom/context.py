# -*- coding: utf-8 -*-
import sys
import urllib.parse as urlparse

import xbmc # type: ignore
import xbmcaddon # type: ignore
import xbmcgui # type: ignore


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')


def get_listitem_value(list_item, method_name: str) -> str:
    method = getattr(list_item, method_name, None)
    if not method:
        return ''

    try:
        return method() or ''
    except Exception:
        return ''


def get_listitem_property(list_item, property_name: str) -> str:
    try:
        return list_item.getProperty(property_name) or ''
    except Exception:
        return ''


def get_selected_url(list_item) -> str:
    candidates = [
        get_listitem_value(list_item, 'getPath'),
        get_listitem_value(list_item, 'getfilename'),
        get_listitem_value(list_item, 'getFilename'),
        get_listitem_property(list_item, 'path'),
        get_listitem_property(list_item, 'file'),
        get_listitem_property(list_item, 'url'),
        get_listitem_property(list_item, 'filename'),
        get_listitem_property(list_item, 'Filename'),
        get_listitem_property(list_item, 'FileNameAndPath'),
        get_listitem_property(list_item, 'filenameandpath'),
    ]

    for candidate in candidates:
        if candidate:
            return candidate

    return ''


def main() -> None:
    list_item = getattr(sys, 'listitem', None)
    if not list_item:
        xbmcgui.Dialog().ok('Mathom', 'No se pudo leer el elemento seleccionado.')
        return

    url = get_selected_url(list_item)
    if not url:
        xbmcgui.Dialog().ok('Mathom', 'No se encontró ningún enlace en el elemento seleccionado.')
        return

    title = get_listitem_value(list_item, 'getLabel') or 'Archivo'
    query = urlparse.urlencode({
        'action': 'context_download',
        'url': url,
        'title': title,
    })
    xbmc.executebuiltin(f'RunPlugin(plugin://{ADDON_ID}/?{query})')


if __name__ == '__main__':
    main()
