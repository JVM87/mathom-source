# -*- coding: utf-8 -*-
import xbmc # type: ignore
import xbmcaddon # type: ignore
import xbmcgui # type: ignore
import xbmcvfs # type: ignore
import time

from resources.lib.downloader import SimpleDownloader
from resources.lib.download_queue import get_item, get_next_queued, mark_stale_running_as_queued, update_item


ADDON = xbmcaddon.Addon('plugin.video.mathom')
MONITOR = xbmc.Monitor()
SERVICE_LOCK = 'Mathom.ServiceRunning'


def join_vfs_path(base_path: str, filename: str) -> str:
    separator = '' if base_path.endswith(('/', '\\')) else '/'
    return f"{base_path}{separator}{filename}"


def get_setting_bool(setting_id: str, default: bool = False) -> bool:
    try:
        value = ADDON.getSetting(setting_id)
        if value == '':
            return default
        return value.lower() in ('true', '1', 'yes', 'on')
    except Exception:
        return default


def process_item(item: dict) -> None:
    download_path = ADDON.getSetting('download_path')
    if not download_path:
        update_item(item['id'], {'status': 'error', 'error': 'Ruta de descarga no configurada.'})
        return

    resume = item.get('status') == 'resuming' or int(item.get('downloaded') or 0) > 0
    current_progress = int(item.get('progress') or 0) if resume else 0
    update_item(item['id'], {'status': 'downloading', 'progress': current_progress, 'error': ''})

    last_progress_write = {'time': 0.0, 'percent': -1}

    def on_progress(percent, downloaded, total, speed, eta):
        current_time = time.time()
        if percent == last_progress_write['percent'] and current_time - last_progress_write['time'] < 0.75:
            return
        if current_time - last_progress_write['time'] < 0.5 and percent < 100:
            return
        last_progress_write['time'] = current_time
        last_progress_write['percent'] = percent
        update_item(item['id'], {
            'status': 'downloading',
            'progress': percent,
            'downloaded': downloaded,
            'total': total,
            'speed': speed,
            'eta': eta,
        })

    def control_download():
        current = get_item(item['id']) or {}
        status = current.get('status')
        if status == 'pausing':
            return 'pause'
        if status == 'canceling':
            return 'cancel'
        return None

    downloader = SimpleDownloader(
        download_path,
        foreground=False,
        progress_callback=on_progress,
        control_callback=control_download,
    )
    ok = downloader.download_http(item['url'], item['filename'], resume=resume)
    if ok:
        update_item(item['id'], {'status': 'completed', 'progress': 100})
    else:
        current = get_item(item['id']) or {}
        status = current.get('status')
        if status == 'pausing':
            update_item(item['id'], {'status': 'paused', 'speed': 0.0, 'eta': ''})
        elif status == 'canceling':
            partial_path = join_vfs_path(download_path, item.get('filename', ''))
            if xbmcvfs.exists(partial_path):
                try:
                    xbmcvfs.delete(partial_path)
                except Exception:
                    pass
            update_item(item['id'], {'status': 'canceled', 'speed': 0.0, 'eta': ''})
        else:
            current_error = current.get('error') or item.get('error') or 'No se pudo completar la descarga.'
            update_item(item['id'], {'status': 'error', 'error': current_error, 'speed': 0.0, 'eta': ''})


def main() -> None:
    window = xbmcgui.Window(10000)
    if window.getProperty(SERVICE_LOCK) == 'true':
        xbmc.log("Mathom: servicio ya activo", xbmc.LOGINFO)
        return

    window.setProperty(SERVICE_LOCK, 'true')
    xbmc.log("Mathom: servicio iniciado", xbmc.LOGINFO)

    try:
        mark_stale_running_as_queued()

        while not MONITOR.abortRequested():
            item = get_next_queued()
            if item:
                if get_setting_bool('show_notifications', True):
                    xbmcgui.Dialog().notification("Mathom", f"Descargando: {item['filename']}", ADDON.getAddonInfo('icon'), 3000)
                process_item(item)
                continue

            if MONITOR.waitForAbort(2):
                break

    finally:
        window.clearProperty(SERVICE_LOCK)
        xbmc.log("Mathom: servicio detenido", xbmc.LOGINFO)


if __name__ == '__main__':
    main()
