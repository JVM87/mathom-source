# -*- coding: utf-8 -*-
import sys
import re
import urllib.parse as urlparse
from urllib.parse import unquote_plus
from typing import Dict, Optional
import xbmc # type: ignore
import xbmcgui # type: ignore
import xbmcplugin # type: ignore
import xbmcvfs # type: ignore
import xbmcaddon # type: ignore
from resources.lib.download_queue import enqueue_download, get_item, list_active, set_status

# --- Inicialización del Addon ---
ADDON: xbmcaddon.Addon = xbmcaddon.Addon()
ADDON_ID: str = ADDON.getAddonInfo('id')
ADDON_VERSION: str = ADDON.getAddonInfo('version')
HANDLE: int = int(sys.argv[1])
BASE_URL: str = sys.argv[0]

# Log de bienvenida profesional
xbmc.log(f"Mathom: Iniciando v{ADDON_VERSION} en Python {sys.version}", xbmc.LOGINFO)

def build_url(query: Dict[str, str]) -> str:
    """Construye una URL para el plugin."""
    return f"{BASE_URL}?{urlparse.urlencode(query)}"

def join_vfs_path(base_path: str, filename: str) -> str:
    """Une rutas sin romper rutas virtuales o remotas de Kodi."""
    separator = '' if base_path.endswith(('/', '\\')) else '/'
    return f"{base_path}{separator}{filename}"

def get_filename(path: str) -> str:
    normalized_path = path.rstrip('/\\')
    return normalized_path.replace('\\', '/').rsplit('/', 1)[-1]

def get_setting_int(setting_id: str, default: int) -> int:
    try:
        value = ADDON.getSetting(setting_id)
        return int(value) if value else default
    except (TypeError, ValueError):
        xbmc.log(f"Mathom: Ajuste inválido '{setting_id}', usando {default}", xbmc.LOGWARNING)
        return default

def get_setting_bool(setting_id: str, default: bool = False) -> bool:
    try:
        value = ADDON.getSetting(setting_id)
        if value == '':
            return default
        return value.lower() in ('true', '1', 'yes', 'on')
    except Exception:
        xbmc.log(f"Mathom: Ajuste booleano inválido '{setting_id}', usando {default}", xbmc.LOGWARNING)
        return default

def get_video_extension(url: str, title: str) -> str:
    allowed_extensions = {'.mp4', '.mkv', '.avi', '.ts', '.mov', '.m4v', '.webm'}
    parsed_path = urlparse.unquote(urlparse.urlparse(url.split('|', 1)[0]).path)
    if parsed_path.lower().endswith(('.m3u8', '.mpd')):
        return '.mp4'

    candidates = [
        parsed_path,
        title,
    ]

    for candidate in candidates:
        filename = get_filename(candidate)
        if '.' not in filename:
            continue
        extension = f".{filename.rsplit('.', 1)[-1].lower()}"
        if extension in allowed_extensions:
            return extension

    return '.mp4'

def strip_video_extension(filename: str) -> str:
    video_extensions = ('.mp4', '.mkv', '.avi', '.ts', '.mov', '.m4v', '.webm')
    lowered_filename = filename.lower()

    for extension in video_extensions:
        if lowered_filename.endswith(extension):
            return filename[:-len(extension)].rstrip()

    return filename

def clean_kodi_label(label: str) -> str:
    cleaned_label = re.sub(r'\[/?COLOR[^\]]*\]', '', label, flags=re.IGNORECASE)
    cleaned_label = re.sub(r'\[[^\]]*\]', ' ', cleaned_label)
    return ' '.join(cleaned_label.split())

def suppress_origin_playback() -> None:
    """Corta la reproducción usada sólo para capturar y cierra avisos del addon origen."""
    for _ in range(6):
        xbmc.Player().stop()
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.sleep(300)

def wake_download_service() -> None:
    service_path = join_vfs_path(ADDON.getAddonInfo('path'), 'service.py')
    xbmc.executebuiltin(f'RunScript("{service_path}")')

def delete_partial_download(filename: str) -> None:
    download_path = ADDON.getSetting('download_path')
    if not download_path or not filename:
        return

    partial_path = join_vfs_path(download_path, filename)
    if xbmcvfs.exists(partial_path):
        try:
            xbmcvfs.delete(partial_path)
        except Exception as exc:
            xbmc.log(f"Mathom: No se pudo borrar parcial {partial_path}: {str(exc)}", xbmc.LOGWARNING)

# --- Navegación ---
def main_menu() -> None:
    """Muestra el menú principal con estética unificada."""
    icon = ADDON.getAddonInfo('icon')
    items = [
        ('Introducir Enlace Manual', 'manual_url', icon, False),
        ('Descargas Activas', 'active_downloads', icon, True),
        ('Mis Descargas', 'downloads', icon, True),
        ('Configuración', 'settings', icon, False)
    ]
    
    for label, action, icon, is_folder in items:
        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({'icon': icon, 'thumb': icon})
        url = build_url({'action': action})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=is_folder)
    
    xbmcplugin.endOfDirectory(HANDLE)

def show_downloads() -> None:
    """Lista el contenido descargado localmente con feedback de vacío."""
    download_path: str = ADDON.getSetting('download_path')
    if not download_path or not xbmcvfs.exists(download_path):
        xbmcgui.Dialog().ok('Mathom', 'Define la ruta de descarga en los ajustes.')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    xbmcplugin.addSortMethod(handle=HANDLE, sortMethod=xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(handle=HANDLE, sortMethod=xbmcplugin.SORT_METHOD_DATE)
    xbmcplugin.addSortMethod(handle=HANDLE, sortMethod=xbmcplugin.SORT_METHOD_SIZE)
    
    _, files = xbmcvfs.listdir(download_path)
    video_files = [f for f in files if f.lower().endswith(('.mp4', '.mkv', '.avi', '.ts', '.mov', '.m4v', '.webm'))]
    
    if not video_files:
        list_item = xbmcgui.ListItem(label="[I](No hay descargas disponibles)[/I]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=list_item, isFolder=False)
    else:
        for file in video_files:
            try:
                path = join_vfs_path(download_path, file)
                stats = xbmcvfs.Stat(path)
                
                list_item = xbmcgui.ListItem(label=file)
                list_item.setInfo('video', {
                    'title': file, 
                    'mediatype': 'movie',
                    'size': stats.st_size()
                })
                list_item.setProperty('IsPlayable', 'true')
                list_item.addContextMenuItems([
                    ('Eliminar descarga', f'RunPlugin({build_url({"action": "delete_local", "path": path})})')
                ])
                
                url = build_url({'action': 'play_local', 'path': path})
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)
            except Exception as e:
                xbmc.log(f"Mathom: Error en {file}: {str(e)}", xbmc.LOGWARNING)
    
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)

def show_active_downloads() -> None:
    """Muestra el estado de la cola gestionada por el servicio."""
    active_items = list_active()
    if not active_items:
        list_item = xbmcgui.ListItem(label="[I](No hay descargas activas)[/I]")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=list_item, isFolder=False)
    else:
        for item in active_items:
            item_id = item.get('id', '')
            status = item.get('status', 'queued')
            progress = int(item.get('progress') or 0)
            downloaded = float(item.get('downloaded') or 0) / 1048576
            total = float(item.get('total') or 0) / 1048576
            speed = float(item.get('speed') or 0)
            eta = item.get('eta') or "--:--"
            filename = item.get('filename', 'Descarga')

            if status == 'queued':
                label = f"[COLOR yellow][En cola][/COLOR] {filename}"
            elif status == 'resuming':
                label = f"[COLOR yellow][Reanudando][/COLOR] {filename}"
            elif status == 'pausing':
                label = f"[COLOR orange][Pausando][/COLOR] {filename} - {progress}%"
            elif status == 'paused':
                if total > 0:
                    label = f"[COLOR orange][Pausada {progress}%][/COLOR] {filename} - {downloaded:.1f}/{total:.1f} MB"
                else:
                    label = f"[COLOR orange][Pausada][/COLOR] {filename} - {downloaded:.1f} MB"
            elif status == 'canceling':
                label = f"[COLOR red][Cancelando][/COLOR] {filename}"
            elif total > 0:
                label = f"[COLOR lime][{progress}%][/COLOR] {filename} - {downloaded:.1f}/{total:.1f} MB - {speed:.1f} MB/s - ETA {eta}"
            else:
                label = f"[COLOR lime][Descargando][/COLOR] {filename} - {downloaded:.1f} MB - {speed:.1f} MB/s"

            list_item = xbmcgui.ListItem(label=label)
            context_items = []
            if item_id:
                if status in ('queued', 'resuming', 'downloading'):
                    context_items.append(('Pausar', f'RunPlugin({build_url({"action": "pause_download", "id": item_id})})'))
                if status == 'paused':
                    context_items.append(('Reanudar', f'RunPlugin({build_url({"action": "resume_download", "id": item_id})})'))
                if status in ('queued', 'resuming', 'downloading', 'pausing', 'paused'):
                    context_items.append(('Cancelar', f'RunPlugin({build_url({"action": "cancel_download", "id": item_id})})'))
                if context_items:
                    list_item.addContextMenuItems(context_items, replaceItems=True)

            url = build_url({'action': 'download_actions', 'id': item_id}) if item_id else ''
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def show_download_actions(item_id: Optional[str]) -> None:
    item = get_item(item_id or '')
    if not item:
        xbmcgui.Dialog().notification("Mathom", "La descarga ya no está activa.", ADDON.getAddonInfo('icon'), 2500)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    status = item.get('status', 'queued')
    actions = []
    if status in ('queued', 'resuming', 'downloading'):
        actions.append(('Pausar', 'pause_download'))
    if status == 'paused':
        actions.append(('Reanudar', 'resume_download'))
    if status in ('queued', 'resuming', 'downloading', 'pausing', 'paused'):
        actions.append(('Cancelar', 'cancel_download'))

    if not actions:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return

    choice = xbmcgui.Dialog().select(item.get('filename', 'Descarga'), [label for label, _ in actions])
    if choice >= 0:
        run_download_action(actions[choice][1], item_id or '')

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

def run_download_action(action: str, item_id: str) -> None:
    item = get_item(item_id)
    if not item:
        xbmcgui.Dialog().notification("Mathom", "La descarga ya no está activa.", ADDON.getAddonInfo('icon'), 2500)
        return

    filename = item.get('filename', 'Descarga')
    status = item.get('status', 'queued')
    if action == 'pause_download':
        next_status = 'pausing' if status == 'downloading' else 'paused'
        set_status(item_id, next_status)
        xbmcgui.Dialog().notification("Mathom", f"Pausando: {filename}", ADDON.getAddonInfo('icon'), 2500)
    elif action == 'resume_download':
        set_status(item_id, 'resuming')
        wake_download_service()
        xbmcgui.Dialog().notification("Mathom", f"Reanudando: {filename}", ADDON.getAddonInfo('icon'), 2500)
    elif action == 'cancel_download':
        if status in ('downloading', 'pausing'):
            set_status(item_id, 'canceling')
        else:
            set_status(item_id, 'canceled')
            delete_partial_download(filename)
        xbmcgui.Dialog().notification("Mathom", f"Cancelando: {filename}", ADDON.getAddonInfo('icon'), 2500)

    xbmc.executebuiltin('Container.Refresh')

# --- Lógica de Negocio ---
def handle_download(url: Optional[str], title: str) -> None:
    """Inicia el proceso de descarga respetando los ajustes de notificaciones."""
    if not url:
        xbmcgui.Dialog().ok('Mathom', 'No se recibió ningún enlace válido.')
        return

    download_path: str = ADDON.getSetting('download_path')
    if not download_path:
        xbmcgui.Dialog().ok('Mathom', 'Configura la ruta de descarga primero.')
        return
    
    if url.startswith('magnet:'):
        xbmcgui.Dialog().ok("Mathom", "La descarga de Torrents P2P estará disponible próximamente.")
    elif url.startswith(('http://', 'https://')):
        # Limpieza profunda del nombre de archivo
        title = clean_kodi_label(title)
        clean_title = "".join([c for c in title if c.isalnum() or c in (' ', '.', '_', '-')]).strip()
        if not clean_title:
            clean_title = "Video_Mathom"
            
        extension = get_video_extension(url, title)
        clean_title = strip_video_extension(clean_title) or "Video_Mathom"
        filename = f"{clean_title}{extension}"
        
        enqueue_download(url, filename, title)
        wake_download_service()
        xbmcgui.Dialog().notification(
            "Mathom",
            f"En cola: {filename}",
            ADDON.getAddonInfo('icon'),
            3000
        )
    else:
        xbmcgui.Dialog().ok('Mathom', 'El enlace debe ser HTTP, HTTPS o Magnet.')

class CapturePlayer(xbmc.Player): # type: ignore
    """Clase para interceptar la URL resuelta por otros addons."""
    def __init__(self):
        super().__init__()
        self.resolved_url: Optional[str] = None

    def onPlayBackStarted(self) -> None:
        self.resolved_url = self.getPlayingFile()
        self.stop()

def handle_context_download(url: Optional[str], title: str) -> None:
    """Captura y descarga desde el menú contextual con blindaje de comandos."""
    if not url:
        xbmcgui.Dialog().ok("Mathom", "No se recibió ningún enlace para capturar.")
        return

    if url.startswith('plugin://'):
        player = CapturePlayer()
        xbmcgui.Dialog().notification(
            "Mathom",
            "Selecciona una fuente en el addon origen...",
            ADDON.getAddonInfo('icon'),
            3000
        )
        xbmc.executebuiltin(f'PlayMedia({url})')
        
        # Timeout dinámico desde ajustes
        timeout = get_setting_int('capture_timeout', 30)
        count = 0
        while not player.resolved_url and count < timeout:
            xbmc.sleep(1000)
            count += 1
        
        captured_url: Optional[str] = player.resolved_url
        del player # Liberar instancia del reproductor inmediatamente
        
        if captured_url:
            url = captured_url
            xbmc.log(f"Mathom: Éxito al capturar: {url}", xbmc.LOGINFO)
            suppress_origin_playback()
        else:
            xbmc.Player().stop()
            xbmc.log(f"Mathom: Fallo por timeout en {title}", xbmc.LOGWARNING)
            xbmcgui.Dialog().ok("Mathom", "No se pudo capturar el enlace.")
            return

    handle_download(url, title)

def play_local(path: Optional[str]) -> None:
    """Reproducción oficial de archivos locales con metadatos."""
    if not path or not xbmcvfs.exists(path):
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok('Mathom', 'No se encontró el archivo local.')
        return

    filename = get_filename(path)
    list_item = xbmcgui.ListItem(label=filename, path=path)
    list_item.setInfo('video', {'title': filename})
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)

def delete_local(path: Optional[str]) -> None:
    """Elimina un archivo descargado tras confirmación explícita."""
    if not path or not xbmcvfs.exists(path):
        xbmcgui.Dialog().notification("Mathom", "No se encontró el archivo.", ADDON.getAddonInfo('icon'), 2500)
        xbmc.executebuiltin('Container.Refresh')
        return

    filename = get_filename(path)
    if not xbmcgui.Dialog().yesno("Mathom", f"¿Eliminar esta descarga?\n\n{filename}"):
        return

    try:
        if xbmcvfs.delete(path):
            xbmcgui.Dialog().notification("Mathom", f"Eliminado: {filename}", ADDON.getAddonInfo('icon'), 2500)
        else:
            xbmcgui.Dialog().ok("Mathom", f"No se pudo eliminar:\n{filename}")
    except Exception as exc:
        xbmc.log(f"Mathom: Error eliminando {path}: {str(exc)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Mathom", f"No se pudo eliminar:\n{filename}\n\n{str(exc)}")

    xbmc.executebuiltin('Container.Refresh')

# --- Router ---
def router(paramstring: str) -> None:
    """Enrutador de acciones del addon."""
    params = dict(urlparse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')

    if not action:
        main_menu()
    elif action == 'manual_url':
        url = xbmcgui.Dialog().input('Introduce Magnet o URL Directa', type=xbmcgui.INPUT_ALPHANUM)
        if url: handle_download(url, 'Descarga_Manual')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    elif action == 'downloads':
        show_downloads()
    elif action == 'active_downloads':
        show_active_downloads()
    elif action == 'download_actions':
        show_download_actions(params.get('id'))
    elif action in ('pause_download', 'resume_download', 'cancel_download'):
        run_download_action(action, params.get('id', ''))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    elif action == 'settings':
        xbmc.executebuiltin(f'Addon.OpenSettings({ADDON_ID})')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    elif action == 'download':
        handle_download(params.get('url'), unquote_plus(params.get('title', 'Vídeo')))
    elif action == 'context_download':
        handle_context_download(params.get('url'), unquote_plus(params.get('title', 'Archivo')))
    elif action == 'play_local':
        play_local(params.get('path'))
    elif action == 'delete_local':
        delete_local(params.get('path'))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

if __name__ == '__main__':
    router(sys.argv[2])
