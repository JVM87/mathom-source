# Mathom (plugin.video.mathom)

Mathom is a high-performance Kodi addon designed to act as an asynchronous download bridge for multimedia content.

## Key Features

- **Bridge Interception**: Capable of intercepting URLs resolved by compatible external addons using a dynamic player capture technique.
- **Asynchronous Downloads**: Background download engine that does not block the Kodi user interface.
- **Library Management**: Dedicated section to view, play, and manage locally downloaded content.
- **Command Shielding**: Secure implementation to prevent code injection and failures caused by special characters in paths.
- **Smart Notifications**: Configurable visual feedback system for download starts and completions.

## Installation

### From GitHub Pages source

1. In Kodi, go to Settings -> File manager -> Add source.
2. Add the Mathom source URL:
   `https://jvm87.github.io/mathom-source/`
3. Go to Add-ons -> Install from ZIP file.
4. Open the Mathom source and install `plugin.video.mathom-1.0.2.zip`.
5. Configure your download path in the addon settings.

### From local ZIP

1. Download the repository or the addon ZIP file.
2. In Kodi, go to Addons -> Install from ZIP file.
3. Configure your download path in the addon settings.

## Disclaimer

This addon is a technical tool for download management. The author is not responsible for any misuse of the tool or the multimedia content downloaded through it.

---
Developed for the Kodi community.
